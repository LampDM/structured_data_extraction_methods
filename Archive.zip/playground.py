import re


# Note: start with ch
#       --> create group channel
#       --> match any character until first : is found
#       --> match next 3 chars --> create group sensors
channel_sensor_index_pattern = r'ch(?P<channel>\d{2}).+?:.{3}(?P<sensor>\d{2})'


def read_output_from_device(file_path):
    _channels = set()
    _sensors = set()

    with open(file_path) as fp:
        file_content = fp.read()

        for match in re.finditer(channel_sensor_index_pattern, file_content):
            _channels.add(match.group('channel'))
            _sensors.add(match.group('sensor'))

    return _channels, _sensors


if __name__ == '__main__':
    sensors_of_interest = ['02', '04']
    channels_of_interest = ['01', '02']
    channels, sensors = read_output_from_device('file_to_read.txt')

    print('are all channels in file?', all([channel in channels for channel in channels_of_interest]))
    print('is any channel in file?', any([channel in channels for channel in channels_of_interest]))

    print('are all sensors in file?', all([sensor in sensors for sensor in sensors_of_interest]))
    print('is any sensor in file?', any([sensor in sensors for sensor in sensors_of_interest]))




